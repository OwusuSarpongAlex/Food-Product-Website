Alex Food - Combined Frontend + Backend (PHP + MySQL)

Project structure (when extracted into your web root):
  alex_food_project/
    HOMEPAGE.html
    products.html
    login.html
    images/
    styles/
    backend/         <-- PHP backend, API, admin panel, database.sql

How to run:
1. Install XAMPP or Laragon and start Apache + MySQL.
2. Copy the entire folder to your web root (e.g., C:\xampp\htdocs\alex_food_project)
3. Import the database: use phpMyAdmin to import backend/database.sql (creates alex_food DB)
4. Edit backend/config.php if your DB user/password differs.
5. Open in browser:
   - Public site: http://localhost/alex_food_project/HOMEPAGE.html
   - Admin panel: http://localhost/alex_food_project/backend/admin/login.php
   - API endpoint (JSON): http://localhost/alex_food_project/backend/api/products.php

Admin login (from database.sql):
  email: admin@alex.test
  password: adminpass

Notes:
- products.html now fetches live product data from the backend API.
- Uploaded product images via admin are stored in backend/uploads/
- If image URLs in DB are relative, products.html will use them directly.
