-- Alex Food - MySQL schema and sample data
CREATE DATABASE IF NOT EXISTS alex_food CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE alex_food;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150),
  email VARCHAR(200) UNIQUE,
  password VARCHAR(255),
  role VARCHAR(50) DEFAULT 'admin',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  price DECIMAL(10,2) DEFAULT 0.00,
  stock INT DEFAULT 0,
  image_url VARCHAR(500),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- sample admin (use register.php to create real admin)
INSERT INTO users (name,email,password,role) VALUES
('Admin','admin@alex.test', '$2y$10$e0NRt3jz5x9QxFvGk1k0auu3Qp3yK8b7JtqvQyQ1Y6k1qzQG1aZHy', 'admin');
-- password is 'adminpass' hashed with password_hash()

INSERT INTO products (name,price,stock,image_url) VALUES
('Oranges',5.00,120,'images/orange.png'),
('Assorted Veg',8.50,50,'images/Rectangle 8.png');
