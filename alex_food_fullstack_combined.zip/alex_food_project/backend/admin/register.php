<?php
require_once __DIR__ . '/../config.php';
$errors=[]; $success=false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? ''; $email = $_POST['email'] ?? ''; $pass = $_POST['password'] ?? '';
    if (!$name||!$email||!$pass) $errors[]='Missing fields';
    else {
        $h = password_hash($pass, PASSWORD_DEFAULT);
        $ins = $pdo->prepare("INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)");
        $ins->execute([$name,$email,$h,'admin']); $success=true;
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Register Admin</title><link rel="stylesheet" href="../styles/admin.css"></head><body>
<div class="wrap"><h1>Register Admin</h1>
<?php if ($errors) echo '<div class="error">'.htmlspecialchars(implode(', ',$errors)).'</div>'; ?>
<?php if ($success) echo '<div class="success">Created. <a href="login.php">Login</a></div>'; ?>
<form method="post" class="card">
<label>Name <input name="name" required></label>
<label>Email <input name="email" required></label>
<label>Password <input name="password" required type="password"></label>
<button>Create</button>
</form></div></body></html>
