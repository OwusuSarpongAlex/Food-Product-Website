<?php
require_once __DIR__ . '/../config.php';
if (empty($_SESSION['user_id'])) { header('Location: login.php'); exit; }
$id = intval($_GET['id'] ?? 0); $stmt=$pdo->prepare("SELECT * FROM products WHERE id = ?"); $stmt->execute([$id]); $p=$stmt->fetch();
if (!$p) { header('Location: index.php'); exit; }
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name = $_POST['name'] ?? ''; $price = $_POST['price'] ?? 0; $stock = $_POST['stock'] ?? 0;
    $image_url = $p['image_url'];
    if (!empty($_FILES['image']) && $_FILES['image']['error']===0) {
        $dir = __DIR__.'/../uploads/'; if(!is_dir($dir)) mkdir($dir,0755,true);
        $fname = time().'_'.basename($_FILES['image']['name']); move_uploaded_file($_FILES['image']['tmp_name'],$dir.$fname);
        $image_url = 'uploads/'.$fname;
    }
    $u = $pdo->prepare("UPDATE products SET name=?,price=?,stock=?,image_url=? WHERE id=?");
    $u->execute([$name,$price,$stock,$image_url,$id]); header('Location: index.php'); exit;
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Edit Product</title><link rel="stylesheet" href="../styles/admin.css"></head><body>
<div class="wrap"><h1>Edit Product</h1>
<form method="post" enctype="multipart/form-data" class="card">
<label>Name <input name="name" required value="<?php echo htmlspecialchars($p['name']);?>"></label>
<label>Price <input name="price" required value="<?php echo htmlspecialchars($p['price']);?>"></label>
<label>Stock <input name="stock" value="<?php echo htmlspecialchars($p['stock']);?>"></label>
<label>Image <input type="file" name="image"></label>
<button>Update</button>
</form></div></body></html>
