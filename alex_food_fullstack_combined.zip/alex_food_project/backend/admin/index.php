<?php
require_once __DIR__ . '/../config.php';
if (empty($_SESSION['user_id'])) { header('Location: login.php'); exit; }
$products = $pdo->query("SELECT * FROM products ORDER BY id DESC")->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin</title><link rel="stylesheet" href="../styles/admin.css"></head><body>
<div class="wrap"><h1>Admin Dashboard</h1><p>Welcome <?php echo htmlspecialchars($_SESSION['user_name'] ?? ''); ?></p>
<p><a href="add.php" class="btn">Add Product</a> <a href="logout.php" class="danger">Logout</a></p>
<div class="card"><h2>Products</h2><table width="100%"><thead><tr><th>ID</th><th>Name</th><th>Price</th><th>Stock</th><th>Action</th></tr></thead><tbody>
<?php foreach($products as $p): ?>
<tr><td><?php echo $p['id'];?></td><td><?php echo htmlspecialchars($p['name']);?></td><td><?php echo htmlspecialchars($p['price']);?></td><td><?php echo htmlspecialchars($p['stock']);?></td>
<td><a href="edit.php?id=<?php echo $p['id'];?>">Edit</a> | <a href="delete.php?id=<?php echo $p['id'];?>" onclick="return confirm('Delete?')">Delete</a></td></tr>
<?php endforeach; ?>
</tbody></table></div></div></body></html>
