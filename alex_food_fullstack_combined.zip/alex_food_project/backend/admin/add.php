<?php
require_once __DIR__ . '/../config.php';
if (empty($_SESSION['user_id'])) { header('Location: login.php'); exit; }
$errors=[];
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name = $_POST['name'] ?? ''; $price = $_POST['price'] ?? 0; $stock = $_POST['stock'] ?? 0;
    $image_url = '';
    if (!empty($_FILES['image']) && $_FILES['image']['error']===0) {
        $dir = __DIR__.'/../uploads/'; if(!is_dir($dir)) mkdir($dir,0755,true);
        $fname = time().'_'.basename($_FILES['image']['name']); move_uploaded_file($_FILES['image']['tmp_name'],$dir.$fname);
        $image_url = 'uploads/'.$fname;
    }
    $ins = $pdo->prepare("INSERT INTO products (name,price,stock,image_url) VALUES (?,?,?,?)");
    $ins->execute([$name,$price,$stock,$image_url]); header('Location: index.php'); exit;
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Add Product</title><link rel="stylesheet" href="../styles/admin.css"></head><body>
<div class="wrap"><h1>Add Product</h1>
<form method="post" enctype="multipart/form-data" class="card">
<label>Name <input name="name" required></label>
<label>Price <input name="price" required></label>
<label>Stock <input name="stock"></label>
<label>Image <input type="file" name="image"></label>
<button>Add</button>
</form></div></body></html>
