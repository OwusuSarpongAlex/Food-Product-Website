<?php
require_once __DIR__ . '/../config.php';
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $pass = $_POST['password'] ?? '';
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]); $u = $stmt->fetch();
    if ($u && password_verify($pass, $u['password'])) {
        $_SESSION['user_id'] = $u['id']; $_SESSION['user_name']=$u['name']; header('Location: index.php'); exit;
    } else { $errors[] = 'Invalid credentials'; }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin Login</title><link rel="stylesheet" href="../styles/admin.css"></head><body>
<div class="wrap"><h1>Admin Login</h1>
<?php if ($errors) echo '<div class="error">'.htmlspecialchars(implode(', ',$errors)).'</div>'; ?>
<form method="post" class="card">
<label>Email <input name="email" required></label>
<label>Password <input name="password" required type="password"></label>
<button>Login</button>
</form>
<p><a href="register.php">Register new admin</a></p>
</div></body></html>
