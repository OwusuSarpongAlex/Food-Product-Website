<?php
require_once __DIR__ . '/../config.php';
if (empty($_SESSION['user_id'])) { header('Location: login.php'); exit; }
$id = intval($_GET['id'] ?? 0);
$pdo->prepare("DELETE FROM products WHERE id = ?")->execute([$id]);
header('Location: index.php'); exit;
