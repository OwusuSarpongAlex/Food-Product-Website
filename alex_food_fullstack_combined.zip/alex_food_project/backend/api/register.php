<?php
require_once __DIR__ . '/../config.php';
$data = json_decode(file_get_contents('php://input'), true) ?? [];
$name = $data['name'] ?? ''; $email = $data['email'] ?? ''; $pass = $data['password'] ?? '';
if (!$name||!$email||!$pass) { http_response_code(400); echo json_encode(['error'=>'Missing']); exit; }
$h = password_hash($pass, PASSWORD_DEFAULT);
$ins = $pdo->prepare("INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)");
$ins->execute([$name,$email,$h,'admin']);
echo json_encode(['success'=>true]);