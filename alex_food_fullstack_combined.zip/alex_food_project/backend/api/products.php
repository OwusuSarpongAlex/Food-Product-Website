<?php
require_once __DIR__ . '/../config.php';

$method = $_SERVER['REQUEST_METHOD'];

// Helper to read JSON body
function getJsonBody() {
    $data = file_get_contents('php://input');
    $d = json_decode($data, true);
    return $d ?: [];
}

if ($method === 'GET') {
    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        if (!$row) { http_response_code(404); echo json_encode(['error'=>'Not found']); exit; }
        echo json_encode($row); exit;
    } else {
        $stmt = $pdo->query("SELECT * FROM products ORDER BY id DESC");
        $rows = $stmt->fetchAll();
        echo json_encode($rows); exit;
    }
}

if ($method === 'POST') {
    // Admin create - accept multipart/form-data for image upload
    $name = $_POST['name'] ?? '';
    $price = $_POST['price'] ?? '0';
    $stock = $_POST['stock'] ?? null;
    $image_url = $_POST['image_url'] ?? '';

    // handle uploaded file
    if (!empty($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $uploadsDir = __DIR__ . '/../uploads/';
        if (!is_dir($uploadsDir)) mkdir($uploadsDir, 0755, true);
        $fname = time() . '_' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $uploadsDir . $fname);
        $image_url = 'uploads/' . $fname;
    }

    $ins = $pdo->prepare("INSERT INTO products (name,price,stock,image_url) VALUES (?,?,?,?)");
    $ins->execute([$name, $price, $stock, $image_url]);
    echo json_encode(['success'=>true,'id'=>$pdo->lastInsertId()]);
    exit;
}

if ($method === 'PUT') {
    parse_str(file_get_contents('php://input'), $put);
    $id = intval($_GET['id'] ?? 0);
    if (!$id) { http_response_code(400); echo json_encode(['error'=>'Missing id']); exit; }
    $data = getJsonBody();
    $name = $data['name'] ?? null;
    $price = $data['price'] ?? null;
    $stock = $data['stock'] ?? null;
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ? LIMIT 1"); $stmt->execute([$id]); $p=$stmt->fetch();
    if (!$p) { http_response_code(404); echo json_encode(['error'=>'Not found']); exit; }
    $u = $pdo->prepare("UPDATE products SET name=?, price=?, stock=? WHERE id=?");
    $u->execute([ $name ?? $p['name'], $price ?? $p['price'], $stock ?? $p['stock'], $id ]);
    echo json_encode(['success'=>true]); exit;
}

if ($method === 'DELETE') {
    $id = intval($_GET['id'] ?? 0);
    if (!$id) { http_response_code(400); echo json_encode(['error'=>'Missing id']); exit; }
    $pdo->prepare("DELETE FROM products WHERE id = ?")->execute([$id]);
    echo json_encode(['success'=>true]); exit;
}

http_response_code(405);
echo json_encode(['error'=>'Method not allowed']);
