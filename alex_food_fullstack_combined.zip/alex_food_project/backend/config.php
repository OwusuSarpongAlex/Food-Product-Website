<?php
// backend/config.php - edit to match your MySQL settings
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'alex_food');
define('DB_USER', 'root');
define('DB_PASS', ''); // change if you have a password

$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS, $options);
} catch (Exception $e) {
    http_response_code(500);
    echo "Database connection failed: " . htmlspecialchars($e->getMessage());
    exit;
}
session_start();
?>