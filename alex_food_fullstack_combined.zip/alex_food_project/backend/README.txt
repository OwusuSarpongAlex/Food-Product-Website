Alex Food Project - Backend (PHP + MySQL)

Place the frontend files (the contents of 'alex food project' folder) together with this backend in your web root (e.g., C:\xampp\htdocs\alex_food_project).
Directory structure should look like:
  htdocs/
    alex_food_project/   <- frontend static files (HOMEPAGE.html, products.html, styles/, images/)
    backend/             <- this folder (api endpoints + admin)
Or merge frontend files into backend's public folder. Both approaches work.

Steps to run (XAMPP/Laragon):
1. Start Apache & MySQL.
2. Create a MySQL database, e.g., 'alex_food' using phpMyAdmin.
3. Import 'database.sql' from this backend folder.
4. Edit 'backend/config.php' DB credentials if needed.
5. To view public site: open the frontend index (HOMEPAGE.html) via http://localhost/alex_food_project/HOMEPAGE.html
6. API endpoints (useful for dynamic frontend):
   - GET backend/api/products.php            -> list all products (JSON)
   - GET backend/api/products.php?id=1       -> get product id=1
   - POST backend/api/products.php (admin)   -> create product (multipart/form-data)
   - PUT backend/api/products.php?id=1       -> update product (JSON body)
   - DELETE backend/api/products.php?id=1    -> delete product (DELETE request)
7. Admin panel: open http://localhost/alex_food_project/backend/admin/login.php to login and manage products.
   - Default admin: email: admin@alex.test  password: adminpass (create via import or register page)

Integration notes:
- The provided static frontend is not wired to call the API. You can either:
  * Update the frontend JS to fetch products from backend/api/products.php (recommended), or
  * Use the admin panel to manage products in the DB and edit static HTML files manually.
